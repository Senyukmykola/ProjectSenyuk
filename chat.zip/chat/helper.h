/*
* - Пакет RIO (надійний ввод-вивод), який дозволяє виконувати зчитування 
*   та запис надійно, обробляючи короткі зчитування та записи. 
*   Він також надає rio_t, який дозволяє виконувати буферизоване зчитування.
*/

#ifndef HELPER_H
#define HELPER_H

#include<stdlib.h>
#include<stdio.h>

#define RIO_BUFSIZE 8192
typedef struct {
    int rio_fd;                /* Дескриптор для цього внутрішнього buf */
    ssize_t rio_cnt;           /* Непрочитані байти у внутрішньому buf */
    char *rio_bufptr;          /* Наступний непрочитаний байт у внутрішньому buf */
    char rio_buf[RIO_BUFSIZE]; /* Внутрішній буфер */
} rio_t;

/* Rio (Robust I/O) пакет */
ssize_t rio_readn(int fd, void *usrbuf, size_t n);
ssize_t rio_writen(int fd, const void *usrbuf, size_t n);
void rio_readinitb(rio_t *rp, int fd);
ssize_t rio_readnb(rio_t *rp, void *usrbuf, size_t n);
ssize_t rio_readlineb(rio_t *rp, void *usrbuf, size_t maxlen);




#endif
