#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netdb.h>
#include <string.h>
#include <errno.h>
#include <pthread.h>
#include "helper.h"

#define MAXLINE 1024 /* максимальна довжина */

char prompt[]="Chatroom> ";
int flag=0;
/*
команди
*/
void usage(){
  printf("-h  довідка\n");
  printf("-a  IP адрес сервера[Required]\n");
  printf("-p  номер порта сервера[Required]\n");
  printf("-u  введіть ваше імʼя[Required]\n");
}


/*
* @brief-: підключає клієнт до сервера
* NOTE-: функція THE проходить список, щоб найди сокет
* @port-: номер порта
* @hostname-: ip адрес сервера
* @return -: дескриптор файла підключення
*/

int connection(char* hostname, char* port){
  int clientfd,rc;
  struct addrinfo hints, *listp, *p;

  memset(&hints, 0, sizeof(struct addrinfo));
  hints.ai_family = AF_INET;
  hints.ai_socktype = SOCK_STREAM; /* Тільки підключення */
  hints.ai_flags |=AI_ADDRCONFIG;
  hints.ai_flags |= AI_NUMERICSERV; //використання фіксованого порта


  if ((rc = getaddrinfo(hostname, port, &hints, &listp)) != 0) {
    fprintf(stderr,"невірний хост або порт\n");
    return -1;
 }

 for (p = listp; p; p = p->ai_next) {
        /* Створення дескриптора сокета */
        clientfd = socket(p->ai_family, p->ai_socktype, p->ai_protocol);
        if (clientfd < 0) {
            continue; /* Наступний сокет */
        }

        /* Підключення до сервера */
        if (connect(clientfd, p->ai_addr, p->ai_addrlen) != -1) {
            break; /* Success */
        }

        /* Не вдалось підкдючитися, спробуйте інше */
        if (close(clientfd) < 0) {
            fprintf(stderr, "open_clientfd: close failed: %s\n",
                    strerror(errno));
            return -1;
        }
    }

    /* Очистка */
    freeaddrinfo(listp);
    if (!p) { /* Всі підключення провалені */
            return -1;
    }
    else { /* Останнє підключення пройшло успішно */
            return clientfd;
    }
}

// відповідь сервера
void reader(void* var){
  char buf[MAXLINE];
  rio_t rio;
  int status;
  int connID=(int)var;
  // ініціалізація структури даних rio
  rio_readinitb(&rio, connID);
  while(1){
     while((status=rio_readlineb(&rio,buf,MAXLINE)) >0){
          // помилка
          if(status == -1)
            exit(1);
          if(!strcmp(buf,"\r\n")){
              break;
            }
          // вихід з сервера
          if (!strcmp(buf,"exit")){
              close(connID);
              exit(0);
            }
          if (!strcmp(buf,"start\n")){

               printf("\n");
            }

          else
             printf("%s",buf);
      }
      // Підказка чату
      printf("%s",prompt);
      fflush(stdout);
  }
}

int main(int argc, char **argv){


  char *address=NULL,*port=NULL,*username=NULL;
  char cmd[MAXLINE];
  char c;
  pthread_t tid;
  // Розбір аргументів командної лінії
  while((c = getopt(argc, argv, "hu:a:p:u:")) != EOF){
    switch(c){
      // довідка
      case 'h':
         usage();
         exit(1);
         break;
      // адрес сервера
      case 'a':
         address=optarg;
         break;
      // порт сервера
      case 'p':
         port=optarg;
         break;
      // імʼя
      case 'u':
         username=optarg;
         break;

      default:
          usage();
          exit(1);

    }


   }

   if(optind  == 1 || port == NULL || address == NULL || username == NULL){
    printf("Недопустиме\n");
    usage();
    exit(1); }

    int connID=connection(address,port);
    if(connID == -1){
       printf("Неможливо підʼєднатися до сервера\n");
       exit(1);
    }
    // добавити нову строку
    sprintf(username,"%s\n",username);

    // відправити серверу ваше імʼя
    if(rio_writen(connID,username,strlen(username)) == -1){
       perror("Неможливо відправити інформацію");
       close(connID);
       exit(1);
    }

    // потік для читання відповіді сервера
    pthread_create(&tid,NULL,reader, (void*)connID);
    // підказка чату
    printf("%s",prompt);
    while(1){
      // читання команди
      if ((fgets(cmd, MAXLINE, stdin) == NULL) && ferror(stdin)) {
            perror("fgets error");
            close(connID);
            exit(1);
        }


      // відправлення запиту серверу
      if (rio_writen(connID,cmd,strlen(cmd)) == -1){
          perror("not able to send the data");
          close(connID);
          exit(1);
        }

    }

}
