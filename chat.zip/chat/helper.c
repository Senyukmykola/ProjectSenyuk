// цей файл реалізує допоміжну функцію, необхідну клієнтському та серверному коду

#include<stdlib.h>
#include<stdio.h>
#include"helper.h"
#include <unistd.h>
#include <errno.h>
#include <string.h>



ssize_t rio_readn(int fd, void *usrbuf, size_t n) {
    size_t nleft = n;
    ssize_t nread;
    char *bufp = usrbuf;

    while (nleft > 0) {
        if ((nread = read(fd, bufp, nleft)) < 0) {
            if (errno != EINTR) {
                return -1; /* errno встановлюється read() */
            }

            /* Перерваний поверненням обробника sig, знову виклик read() */
            nread = 0;
        } else if (nread == 0) {
            break; /* EOF */
        }
        nleft -= (size_t)nread;
        bufp += nread;
    }
    return (ssize_t)(n - nleft); /* Return >= 0 */
}

/*
 * rio_writen - Надійний запис n байтів (небуферизовані)
 */
ssize_t rio_writen(int fd, const void *usrbuf, size_t n) {
    size_t nleft = n;
    ssize_t nwritten;
    const char *bufp = usrbuf;

    while (nleft > 0) {
        if ((nwritten = write(fd, bufp, nleft)) <= 0) {
            if (errno != EINTR) {
                return -1; /* errno встановлюється write() */
            }

            /* Переривається поверненням обробника sig, виклик write() знову */
            nwritten = 0;
        }
        nleft -= (size_t)nwritten;
        bufp += nwritten;
    }
    return (ssize_t)n;
}

/*
 * rio_read - Це оболонка для функції Unix read(), яка.
 * передає min(n, rio_cnt) байт із внутрішнього буфера в
 * буфер користувача, де n - кількість байт, запрошених користувачем, а
 * rio_cnt - кількість непрочитаних байт у внутрішньому буфері.
 * При вході, rio_read() поповняє внутрішній буфер через виклик
 * функції read(), якщо внутрішній буфер пустий.
 */
static ssize_t rio_read(rio_t *rp, char *usrbuf, size_t n) {
    size_t cnt;

    while (rp->rio_cnt <= 0) { /* Заповнити якщо buffer пустий */
        rp->rio_cnt = read(rp->rio_fd, rp->rio_buf, sizeof(rp->rio_buf));
        if (rp->rio_cnt < 0) {
            if (errno != EINTR) {
                return -1; /* errno встановлюється read() */
            }

            /* Перерваний обробником сигналу, нічого не робити */
        } else if (rp->rio_cnt == 0) {
            return 0; /* EOF */
        } else {
            rp->rio_bufptr = rp->rio_buf; /* Перзавантажити buffer ptr */
        }
    }

    /* Копіювання min(n, rp->rio_cnt) байтів з внутрішнього buf в користувацький buf */
    cnt = n;
    if ((size_t)rp->rio_cnt < n) {
        cnt = (size_t)rp->rio_cnt;
    }
    memcpy(usrbuf, rp->rio_bufptr, cnt);
    rp->rio_bufptr += cnt;
    rp->rio_cnt -= cnt;
    return (ssize_t)cnt;
}

/*
 * rio_readinitb - Зʼєднання дескриптора з буфером зчитування і скидання
 */
void rio_readinitb(rio_t *rp, int fd) {
    rp->rio_fd = fd;
    rp->rio_cnt = 0;
    rp->rio_bufptr = rp->rio_buf;
}

/*
 * rio_readnb - Надійно зчитує n байтів (buffered)
 */
ssize_t rio_readnb(rio_t *rp, void *usrbuf, size_t n) {
    size_t nleft = n;
    ssize_t nread;
    char *bufp = usrbuf;

    while (nleft > 0) {
        if ((nread = rio_read(rp, bufp, nleft)) < 0) {
            return -1; /* errno встановлюється read() */
        } else if (nread == 0) {
            break; /* EOF */
        }
        nleft -= (size_t)nread;
        bufp += nread;
    }
    return (ssize_t)(n - nleft); /* return >= 0 */
}

/*
 * rio_readlineb - Надійне зчитування текстової строки
 */
ssize_t rio_readlineb(rio_t *rp, void *usrbuf, size_t maxlen) {
    size_t n;
    ssize_t rc;
    char c, *bufp = usrbuf;

    for (n = 1; n < maxlen; n++) {
        if ((rc = rio_read(rp, &c, 1)) == 1) {
            *bufp++ = c;
            if (c == '\n') {
                n++;
                break;
            }
        } else if (rc == 0) {
            if (n == 1) {
                return 0; /* EOF, ніякої інформації не було прочитано */
            } else {
                break; /* EOF, частина інформації була прочитана */
            }
        } else {
            return -1; /* Помилка */
        }
    }
    *bufp = 0;
    return (ssize_t)(n - 1);
}
