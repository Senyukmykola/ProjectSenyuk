#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netdb.h>
#include <string.h>
#include <errno.h>
#include <pthread.h>
#include "helper.h"


#define bufsize 1000

// блокування до глобального доступа до даних
pthread_mutex_t mutex;

struct client{
    char *name;
    int confd;
    struct client *next;
};

struct client *header=NULL;

//**********************************************************************************

/*
 * @brief-: додавання користувача до глобального DATA_STRUCTURES
 * INSERTION AN HEAD -> O(1) complexity
*/

void add_user(struct client *user){

   if(header == NULL){
     header=user;
     user->next=NULL;
   }
   else{
      user->next=header;

      header=user;
   }
}
/*
 * @brief-: видалення клієнта з глобального списку
 *  O(n) complexity
 */
void delete_user(confd){
   struct client *user=header;
   struct client *previous=NULL;
   // ідентифікація користувача
   while(user->confd!=confd){
     previous=user;
     user=user->next;
   }

   if(previous == NULL)
      header=user->next;

   else
     previous->next=user->next;


   free(user->name);
   free(user);

}

/*
* @brief-: призначає сокет списку на заданий номер порту
* NOTE-: функція проходить по списку, щоб знайти відповідне підключення до сокета для сервера
* @port-: номер порта
* @return -: дескриптор файлу списку
*/
int connection(char * port){

   struct addrinfo *p, *listp, hints;
   int rc,listenfd,optval=1;

   // ініціалізувати на нуль
   memset(&hints,0,sizeof(struct addrinfo));
   hints.ai_family = AF_INET;
   hints.ai_socktype = SOCK_STREAM; /* Тільки підключення */
   hints.ai_flags =AI_ADDRCONFIG|AI_PASSIVE;
   hints.ai_flags |= AI_NUMERICSERV; //використання фіксованого порта

   if ((rc = getaddrinfo(NULL, port, &hints, &listp)) != 0) {
     fprintf(stderr,"get_address номер порта %s невірний\n",port);
     return -1;
  }

   // проходження списку доступних підключень
   for (p = listp; p; p = p->ai_next) {

       listenfd = socket(p->ai_family, p->ai_socktype, p->ai_protocol);
       if (listenfd < 0) {
         continue; /* Збій сокета, спробуйте наступний */
       }

       /* Усуває помилку "Адреса вже використовується" з прив'язування */
      setsockopt(listenfd, SOL_SOCKET, SO_REUSEADDR, (const void *)&optval,sizeof(int));
      //прив’язка сокета, повертає 0 у випадку успіху
      if (bind(listenfd, p->ai_addr, p->ai_addrlen) == 0) {
          break; /* Успіх */
      }
      if (close(listenfd) < 0) { /* Не вдалося прив’язати, спробуйте наступне */
            fprintf(stderr, "open_listenfd збій закриття: %s\n",
                    strerror(errno));
            return -1;
        }

    }

    // уникнення витоку пам'яті
    freeaddrinfo(listp);
    if (!p) { /* Збій всіх підключень */
        return -1;
    }

    // встановлення відставання на 1024 , бажане значення
    // налащтування сокета на listen
    if (listen(listenfd, 1024) < 0) {
            close(listenfd);
            return -1;
        }

      return listenfd;
}

/*
 * відправлення повідомлення всім користувачам
 */
void send_msg(int confd,char* msg, char* receiver, char* sender){

    char response[bufsize];
    struct client *user=header;
    if(receiver == NULL)
     while (user != NULL){
      if (user->confd == confd){
         strcpy(response,"повідомлення відправлено\n\r\n");
         rio_writen(user->confd,response,strlen(response));
       }

      else{
         sprintf(response,"старт\n%s:%s\n\r\n",sender,msg);
         rio_writen(user->confd,response,strlen(response));
      }
      user=user->next;
    }
   else{
       while (user != NULL){
         if(!strcmp(user->name,receiver)){
           sprintf(response,"старт\n%s:%s\n\r\n",sender,msg);
           rio_writen(user->confd,response,strlen(response));
           strcpy(response,"повідомлення відправлено\n\r\n");
           rio_writen(confd,response,strlen(response));
           return;
         }
         user=user->next;
       }
        strcpy(response,"користувача не знайдено\n\r\n");
        rio_writen(confd,response,strlen(response));

   }

}

void evaluate(char *buf ,int confd ,char *username){

  char response[bufsize];
  char msg[bufsize];
  char receiver[bufsize];
  char keyword[bufsize];
  // очистка буфера
  msg[0]='\0';
  receiver[0]='\0';
  keyword[0]='\0';
  struct client *user=header;


  if(!strcmp(buf,"help")){
        sprintf(response,"msg \"text\" : відправити повідомлення всім користувачам онлайн\n");
        sprintf(response,"%smsg \"text\" user : відправити повідомлення певному користувачу\n",response);
        sprintf(response,"%sonline : отримати ім’я всіх користувачів онлайн\n",response);
        sprintf(response,"%squit : вийти з чату\n\r\n",response);
        rio_writen(confd,response,strlen(response));
        return;
   }
   // отримати ім’я користувача 
   if (!strcmp(buf,"online")){
        // очистка буфера
        response[0]='\0';
        // глобальний доступ має бути виключним
        pthread_mutex_lock(&mutex);
        while(user!=NULL){
        sprintf(response,"%s%s\n",response,user->name);
        user=user->next;

        }
    sprintf(response,"%s\r\n",response);
    // глобальний доступ має бути ексклюзивним
    pthread_mutex_unlock(&mutex);
    rio_writen(confd,response,strlen(response));
    return;
   }

   if (!strcmp(buf,"вихід")){
      pthread_mutex_lock(&mutex);
      delete_user(confd);
      pthread_mutex_unlock(&mutex);
      strcpy(response,"exit");
      rio_writen(confd,response,strlen(response));
      close(confd);
      return;

   }

   sscanf(buf,"%s \" %[^\"] \"%s",keyword,msg,receiver);

   if (!strcmp(keyword,"повідомлення")){

        pthread_mutex_lock(&mutex);
        send_msg(confd,msg,receiver,username);
        pthread_mutex_unlock(&mutex);
   }
  else {
     strcpy(response,"Неправильна команда\n\r\n");
     rio_writen(confd,response,strlen(response));

  }

}
/*
* @brief-: функція обробляє вхідних клієнтів одночасно
* @vargp-: покажчик на дескриптор файлу підключення
*/
void* client_handler(void *vargp ){

  char username[bufsize];
  rio_t rio;
  struct client *user;
  long byte_size;
  char buf[bufsize];
  // відʼєднання потока від пірів
  // тому більше не потрібно
  // закінчувати основним потоком
   pthread_detach(pthread_self());

   // збереження з'єднання fd у стеку функцій
   int confd = *((int *)vargp);
   rio_readinitb(&rio, confd);

    // зчитувати імʼя користувача як один рядок, -1 для обробки помилок
    if( (byte_size=rio_readlineb(&rio,username,bufsize)) == -1){
         close(confd);
         free(vargp);
         return NULL;
    }
    // видалити новий рядок
    username[byte_size-1]='\0';
    // призначити простір у глобальній структурі
    user=malloc(sizeof(struct client));
    // error handling
    if (user == NULL){
      perror("пам'ять не може бути призначена");
      close(confd);
      free(vargp);
      return NULL;
    }
    // user->name=username небезаечний
    // оскільки локальний стек може бути доступний одноранговим потокам
    user->name=malloc(sizeof(username));
    memcpy(user->name,username,strlen(username)+1);
    user->confd=confd;

    // заблокувати
    pthread_mutex_lock(&mutex);
    add_user(user);
    // розблокувати
    pthread_mutex_unlock(&mutex);

    // прочитати відповідь клієнта
    while((byte_size=rio_readlineb(&rio,buf,bufsize)) >0){

        // видалити новий рядок
        buf[byte_size-1]='\0';
        // вжити відповідних заходів
        evaluate(buf,confd,username);

    }

    return NULL;
}

int main(int argc,char **argv){
  struct sockaddr_storage clientaddr;
  socklen_t clientlen;
  int listen=-1;
  char host[1000];
  char *port="80";
  int *confd;
  pthread_t tid;

  if (argc > 1)
    port=argv[1];

  // створення дескриптора файлу підключення
  listen= connection(port);

  // Збій підключення
  if(listen == -1){
   printf("connection failed\n");
   exit(1);
  }

  printf("waiting at localhost and port '%s' \n",port);

  // цикл, щоб продовжувати приймати клієнтів
  while(1){
      confd=malloc(sizeof(int));
      *confd=accept(listen, (struct sockaddr *)&clientaddr, &clientlen);
      printf("A new client is online\n");
      // призначити окремий потік для роботи з новим клієнтом
       pthread_create(&tid,NULL,client_handler, confd);

  }

}
